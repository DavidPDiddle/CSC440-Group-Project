﻿namespace MtG_Project
{
    partial class Deck_Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Deck_Menu));
            this.deckContentsBox = new System.Windows.Forms.ListBox();
            this.deckListBox = new System.Windows.Forms.ListBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.addNewButton = new MtG_Project.RoundedButtons();
            this.saveAdditionButton = new MtG_Project.RoundedButtons();
            this.roundedButtons1 = new MtG_Project.RoundedButtons();
            this.editButton = new MtG_Project.RoundedButtons();
            this.exitScreenButton = new MtG_Project.RoundedButtons();
            this.notInCollectionButton = new MtG_Project.RoundedButtons();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // deckContentsBox
            // 
            this.deckContentsBox.FormattingEnabled = true;
            this.deckContentsBox.Location = new System.Drawing.Point(9, 41);
            this.deckContentsBox.Margin = new System.Windows.Forms.Padding(2);
            this.deckContentsBox.Name = "deckContentsBox";
            this.deckContentsBox.Size = new System.Drawing.Size(305, 251);
            this.deckContentsBox.TabIndex = 21;
            this.deckContentsBox.SelectedIndexChanged += new System.EventHandler(this.deckContentsBox_SelectedIndexChanged);
            // 
            // deckListBox
            // 
            this.deckListBox.FormattingEnabled = true;
            this.deckListBox.Location = new System.Drawing.Point(334, 41);
            this.deckListBox.Margin = new System.Windows.Forms.Padding(2);
            this.deckListBox.Name = "deckListBox";
            this.deckListBox.Size = new System.Drawing.Size(304, 251);
            this.deckListBox.TabIndex = 31;
            this.deckListBox.SelectedIndexChanged += new System.EventHandler(this.deckListBox_SelectedIndexChanged);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(661, 10);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(199, 281);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 34;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(339, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 13);
            this.label1.TabIndex = 35;
            this.label1.Text = "List of Decks";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 17);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 13);
            this.label2.TabIndex = 36;
            this.label2.Text = "Deck List";
            // 
            // addNewButton
            // 
            this.addNewButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addNewButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addNewButton.ForeColor = System.Drawing.Color.GhostWhite;
            this.addNewButton.Image = ((System.Drawing.Image)(resources.GetObject("addNewButton.Image")));
            this.addNewButton.Location = new System.Drawing.Point(252, 306);
            this.addNewButton.Name = "addNewButton";
            this.addNewButton.Size = new System.Drawing.Size(47, 52);
            this.addNewButton.TabIndex = 37;
            this.addNewButton.Text = "Add New";
            this.addNewButton.UseVisualStyleBackColor = true;
            this.addNewButton.Click += new System.EventHandler(this.AddNewButton_Click);
            // 
            // saveAdditionButton
            // 
            this.saveAdditionButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.saveAdditionButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saveAdditionButton.ForeColor = System.Drawing.Color.Peru;
            this.saveAdditionButton.Image = ((System.Drawing.Image)(resources.GetObject("saveAdditionButton.Image")));
            this.saveAdditionButton.Location = new System.Drawing.Point(305, 307);
            this.saveAdditionButton.Name = "saveAdditionButton";
            this.saveAdditionButton.Size = new System.Drawing.Size(48, 51);
            this.saveAdditionButton.TabIndex = 38;
            this.saveAdditionButton.Text = "Save";
            this.saveAdditionButton.UseVisualStyleBackColor = true;
            this.saveAdditionButton.Click += new System.EventHandler(this.SaveAdditionButton_Click);
            // 
            // roundedButtons1
            // 
            this.roundedButtons1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.roundedButtons1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.roundedButtons1.ForeColor = System.Drawing.Color.Goldenrod;
            this.roundedButtons1.Image = ((System.Drawing.Image)(resources.GetObject("roundedButtons1.Image")));
            this.roundedButtons1.Location = new System.Drawing.Point(359, 312);
            this.roundedButtons1.Name = "roundedButtons1";
            this.roundedButtons1.Size = new System.Drawing.Size(49, 43);
            this.roundedButtons1.TabIndex = 39;
            this.roundedButtons1.Text = "View";
            this.roundedButtons1.UseVisualStyleBackColor = true;
            // 
            // editButton
            // 
            this.editButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.editButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.editButton.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.editButton.Image = ((System.Drawing.Image)(resources.GetObject("editButton.Image")));
            this.editButton.Location = new System.Drawing.Point(414, 306);
            this.editButton.Name = "editButton";
            this.editButton.Size = new System.Drawing.Size(49, 52);
            this.editButton.TabIndex = 40;
            this.editButton.Text = "Edit";
            this.editButton.UseVisualStyleBackColor = true;
            this.editButton.Click += new System.EventHandler(this.editButton_Click);
            // 
            // exitScreenButton
            // 
            this.exitScreenButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.exitScreenButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exitScreenButton.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.exitScreenButton.Image = ((System.Drawing.Image)(resources.GetObject("exitScreenButton.Image")));
            this.exitScreenButton.Location = new System.Drawing.Point(483, 301);
            this.exitScreenButton.Name = "exitScreenButton";
            this.exitScreenButton.Size = new System.Drawing.Size(54, 55);
            this.exitScreenButton.TabIndex = 41;
            this.exitScreenButton.Text = "Exit";
            this.exitScreenButton.UseVisualStyleBackColor = true;
            this.exitScreenButton.Click += new System.EventHandler(this.ExitScreenButton_Click);
            // 
            // notInCollectionButton
            // 
            this.notInCollectionButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.notInCollectionButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.notInCollectionButton.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.notInCollectionButton.Image = ((System.Drawing.Image)(resources.GetObject("notInCollectionButton.Image")));
            this.notInCollectionButton.Location = new System.Drawing.Point(554, 301);
            this.notInCollectionButton.Name = "notInCollectionButton";
            this.notInCollectionButton.Size = new System.Drawing.Size(60, 63);
            this.notInCollectionButton.TabIndex = 42;
            this.notInCollectionButton.Text = "Not in Collection";
            this.notInCollectionButton.UseVisualStyleBackColor = true;
            this.notInCollectionButton.Click += new System.EventHandler(this.notInCollectionButton_Click);
            // 
            // Deck_Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PaleGreen;
            this.ClientSize = new System.Drawing.Size(872, 366);
            this.Controls.Add(this.notInCollectionButton);
            this.Controls.Add(this.exitScreenButton);
            this.Controls.Add(this.editButton);
            this.Controls.Add(this.roundedButtons1);
            this.Controls.Add(this.saveAdditionButton);
            this.Controls.Add(this.addNewButton);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.deckListBox);
            this.Controls.Add(this.deckContentsBox);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Deck_Menu";
            this.Text = "Deck Menu";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ListBox deckContentsBox;
        private System.Windows.Forms.ListBox deckListBox;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private RoundedButtons addNewButton;
        private RoundedButtons saveAdditionButton;
        private RoundedButtons roundedButtons1;
        private RoundedButtons editButton;
        private RoundedButtons exitScreenButton;
        private RoundedButtons notInCollectionButton;
    }
}