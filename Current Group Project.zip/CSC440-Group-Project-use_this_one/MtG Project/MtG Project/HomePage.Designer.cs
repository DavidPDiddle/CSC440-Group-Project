﻿namespace MtG_Project
{
    partial class HomePage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HomePage));
            this.titleLabel = new System.Windows.Forms.Label();
            this.collectionMenuButton = new MtG_Project.RoundedButtons();
            this.deckMenuButton = new MtG_Project.RoundedButtons();
            this.updateButton = new MtG_Project.RoundedButtons();
            this.SuspendLayout();
            // 
            // titleLabel
            // 
            this.titleLabel.AutoSize = true;
            this.titleLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titleLabel.Location = new System.Drawing.Point(188, 109);
            this.titleLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.titleLabel.Name = "titleLabel";
            this.titleLabel.Size = new System.Drawing.Size(210, 24);
            this.titleLabel.TabIndex = 0;
            this.titleLabel.Text = "Welcome to SnapKeep!";
            // 
            // collectionMenuButton
            // 
            this.collectionMenuButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.collectionMenuButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.collectionMenuButton.ForeColor = System.Drawing.Color.White;
            this.collectionMenuButton.Image = ((System.Drawing.Image)(resources.GetObject("collectionMenuButton.Image")));
            this.collectionMenuButton.Location = new System.Drawing.Point(150, 179);
            this.collectionMenuButton.Name = "collectionMenuButton";
            this.collectionMenuButton.Size = new System.Drawing.Size(100, 97);
            this.collectionMenuButton.TabIndex = 1;
            this.collectionMenuButton.Text = "Collection Menu";
            this.collectionMenuButton.UseVisualStyleBackColor = true;
            this.collectionMenuButton.Click += new System.EventHandler(this.CollectionMenuButton_Click);
            // 
            // deckMenuButton
            // 
            this.deckMenuButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.deckMenuButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deckMenuButton.ForeColor = System.Drawing.Color.White;
            this.deckMenuButton.Image = ((System.Drawing.Image)(resources.GetObject("deckMenuButton.Image")));
            this.deckMenuButton.Location = new System.Drawing.Point(256, 173);
            this.deckMenuButton.Name = "deckMenuButton";
            this.deckMenuButton.Size = new System.Drawing.Size(103, 103);
            this.deckMenuButton.TabIndex = 2;
            this.deckMenuButton.Text = "Deck Menu";
            this.deckMenuButton.UseVisualStyleBackColor = true;
            this.deckMenuButton.Click += new System.EventHandler(this.DeckMenuButton_Click);
            // 
            // updateButton
            // 
            this.updateButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.updateButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.updateButton.ForeColor = System.Drawing.Color.White;
            this.updateButton.Image = ((System.Drawing.Image)(resources.GetObject("updateButton.Image")));
            this.updateButton.Location = new System.Drawing.Point(365, 173);
            this.updateButton.Name = "updateButton";
            this.updateButton.Size = new System.Drawing.Size(100, 103);
            this.updateButton.TabIndex = 4;
            this.updateButton.Text = "Update Card Bank";
            this.updateButton.UseVisualStyleBackColor = true;
            this.updateButton.Click += new System.EventHandler(this.UpdateButton_Click);
            // 
            // HomePage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PaleGreen;
            this.ClientSize = new System.Drawing.Size(600, 366);
            this.Controls.Add(this.updateButton);
            this.Controls.Add(this.deckMenuButton);
            this.Controls.Add(this.collectionMenuButton);
            this.Controls.Add(this.titleLabel);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "HomePage";
            this.Text = "Home Page";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label titleLabel;
        private RoundedButtons collectionMenuButton;
        private RoundedButtons deckMenuButton;
        private RoundedButtons updateButton;
    }
}

