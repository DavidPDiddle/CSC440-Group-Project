﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MtG_Project
{
    public partial class Playtest : Form
    {
        public Playtest()
        {
            InitializeComponent();
        }

        private void CloseButton_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void confirmChoiceButton_Click(object sender, EventArgs e)
        {
            closeButton.Visible = true;
            underConstructionLabel.Visible = true;
            confirmChoiceButton.Visible = false;
            pickDeckLabel.Visible = false;
            deckListBox.Visible = false;
        }
    }
}
