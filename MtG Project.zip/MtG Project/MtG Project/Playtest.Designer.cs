﻿namespace MtG_Project
{
    partial class Playtest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.underConstructionLabel = new System.Windows.Forms.Label();
            this.closeButton = new System.Windows.Forms.Button();
            this.pickDeckLabel = new System.Windows.Forms.Label();
            this.deckListBox = new System.Windows.Forms.ListBox();
            this.confirmChoiceButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // underConstructionLabel
            // 
            this.underConstructionLabel.AutoSize = true;
            this.underConstructionLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.underConstructionLabel.Location = new System.Drawing.Point(134, 167);
            this.underConstructionLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.underConstructionLabel.Name = "underConstructionLabel";
            this.underConstructionLabel.Size = new System.Drawing.Size(293, 26);
            this.underConstructionLabel.TabIndex = 0;
            this.underConstructionLabel.Text = "Currently Under Construction";
            this.underConstructionLabel.Visible = false;
            // 
            // closeButton
            // 
            this.closeButton.BackColor = System.Drawing.Color.Blue;
            this.closeButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.closeButton.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.closeButton.Location = new System.Drawing.Point(228, 221);
            this.closeButton.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.closeButton.Name = "closeButton";
            this.closeButton.Size = new System.Drawing.Size(100, 57);
            this.closeButton.TabIndex = 1;
            this.closeButton.Text = "Close";
            this.closeButton.UseVisualStyleBackColor = false;
            this.closeButton.Visible = false;
            this.closeButton.Click += new System.EventHandler(this.CloseButton_Click);
            // 
            // pickDeckLabel
            // 
            this.pickDeckLabel.AutoSize = true;
            this.pickDeckLabel.Location = new System.Drawing.Point(105, 68);
            this.pickDeckLabel.Name = "pickDeckLabel";
            this.pickDeckLabel.Size = new System.Drawing.Size(126, 13);
            this.pickDeckLabel.TabIndex = 2;
            this.pickDeckLabel.Text = "Pick a deck to play with: ";
            // 
            // deckListBox
            // 
            this.deckListBox.FormattingEnabled = true;
            this.deckListBox.Items.AddRange(new object[] {
            "Eggs Sunnyside Up",
            "Cawblade",
            "5-Color Planeswalkers",
            "Jeskai Group Hug",
            "Goblins EDH"});
            this.deckListBox.Location = new System.Drawing.Point(228, 68);
            this.deckListBox.Name = "deckListBox";
            this.deckListBox.Size = new System.Drawing.Size(165, 17);
            this.deckListBox.TabIndex = 3;
            // 
            // confirmChoiceButton
            // 
            this.confirmChoiceButton.BackColor = System.Drawing.Color.DarkGreen;
            this.confirmChoiceButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.confirmChoiceButton.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.confirmChoiceButton.Location = new System.Drawing.Point(228, 108);
            this.confirmChoiceButton.Margin = new System.Windows.Forms.Padding(2);
            this.confirmChoiceButton.Name = "confirmChoiceButton";
            this.confirmChoiceButton.Size = new System.Drawing.Size(100, 57);
            this.confirmChoiceButton.TabIndex = 4;
            this.confirmChoiceButton.Text = "Confirm";
            this.confirmChoiceButton.UseVisualStyleBackColor = false;
            this.confirmChoiceButton.Click += new System.EventHandler(this.confirmChoiceButton_Click);
            // 
            // Playtest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(600, 366);
            this.Controls.Add(this.confirmChoiceButton);
            this.Controls.Add(this.deckListBox);
            this.Controls.Add(this.pickDeckLabel);
            this.Controls.Add(this.closeButton);
            this.Controls.Add(this.underConstructionLabel);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Playtest";
            this.Text = "Playtest";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label underConstructionLabel;
        private System.Windows.Forms.Button closeButton;
        private System.Windows.Forms.Label pickDeckLabel;
        private System.Windows.Forms.ListBox deckListBox;
        private System.Windows.Forms.Button confirmChoiceButton;
    }
}